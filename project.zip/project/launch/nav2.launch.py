from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.substitutions import FindPackageShare
import os

def generate_launch_description():

    nav2_dir = FindPackageShare('nav2_bringup').find('nav2_bringup')
    config_dir = FindPackageShare('project').find('project')

    return LaunchDescription([

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(nav2_dir, 'launch', 'bringup_launch.py')),
            launch_arguments={
                'use_sim_time': 'true',
                'autostart': 'true',
                'map': os.path.join(config_dir, 'maps', 'map_1768423516.yaml'),
                'params_file': os.path.join(config_dir, 'config', 'nav2_params.yaml')
            }.items()
        )
    ])


from launch import LaunchDescription
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
import os
from launch.actions import  ExecuteProcess
from launch.substitutions import Command
   
   
def generate_launch_description():

    description = FindPackageShare(package="project").find("project")

    urdf_model_path = os.path.join(description, "urdf","mobile_robot.urdf")

    world_file = os.path.join(description, "worlds","smart_warehouse.world")
                
    with open(urdf_model_path,"r") as infp:
        robot_description = infp.read()
          
        robot_state_publisher = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        parameters=[
            {
                "robot_description": robot_description,
                "use_sim_time": True,
            }
        ],
        remappings=[('/clock', '/fast_clock'),] 
    ) 
    
    # Publish joint states if GUI is not enabled
    joint_state_publisher = Node(
        package="joint_state_publisher",
        executable="joint_state_publisher",
        name="joint_state_publisher",
        parameters=[{"use_sim_time": True}],
        )
        
        
        # 1. Launch Gazebo Ignition Fortress with the world
    ign = ExecuteProcess(
        cmd=['ign', 'gazebo', world_file],            
        output='screen'
    )

        # 2. Spawn robot entity in Gazebo
    spawn_entity = Node(
        package='ros_ign_gazebo',
        executable='create',
        output='screen',
        arguments=[
            '-name', 'mobile_robot',
             "-topic", "robot_description",
             '-z', '0.15'
             ],
    )
        

        # 3. Start the ROS–Ignition bridge
    bridge= Node(
        package='ros_ign_bridge',
        executable='parameter_bridge',
        name='ros_ign_bridge',
        output='screen',
	arguments=[
            "/joint_states@sensor_msgs/msg/JointState@ignition.msgs.Model",
            "/lidar@sensor_msgs/msg/LaserScan@ignition.msgs.LaserScan",
    	    "/odom@nav_msgs/msg/Odometry@ignition.msgs.Odometry",
    	    "/imu@sensor_msgs/msg/Imu@ignition.msgs.IMU",
    	    "/cmd_vel@geometry_msgs/msg/Twist@ignition.msgs.Twist",
   	    "/model/mobile_robot/tf@tf2_msgs/msg/TFMessage@ignition.msgs.Pose_V",
	],
	parameters=[{"use_sim_time": True}],
        remappings=[('/model/mobile_robot/tf', '/tf'),
                      ('/clock', '/fast_clock'),
                    ],
    )
    
    clock_bridge= Node(
        package="ros_ign_bridge",
        executable="parameter_bridge",
        name="clock_bridge",
        arguments=[
                    "/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock",
                   
        ],

        output="screen",
        parameters=[{"use_sim_time": True}],
        remappings=[('/clock', '/fast_clock'),] 
    )
    
    lidar_tf_static = Node(
        package= "tf2_ros",
        executable= "static_transform_publisher",
        name= "static_lidar_tf",
        parameters=[{"use_sim_time": True}],
        arguments=["0","0","0","0","0","0","laser_frame","mobile_robot/base_link/gpu_lidar"],
        remappings=[('/clock', '/fast_clock'),]
    )

    ld = LaunchDescription()
    # Add launch actions to start Gazebo, the robot state publisher, and RViz
    ld.add_action(joint_state_publisher)
    ld.add_action(robot_state_publisher)
    ld.add_action(ign)
    ld.add_action(spawn_entity)
    ld.add_action(bridge)
    ld.add_action(clock_bridge)
    ld.add_action(lidar_tf_static)
    
    
    return ld

from launch import LaunchDescription
from launch.actions import ExecuteProcess

def generate_launch_description():

    return LaunchDescription([
        ExecuteProcess(
            cmd=[
                'ign', 'gazebo',
                '/home/seif/ROS_ws/src/project/worlds/smart_warehouse.world'
            ],
            output='screen'
        )
    ])

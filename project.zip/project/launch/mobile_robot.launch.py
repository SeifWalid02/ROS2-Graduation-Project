from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os


def generate_launch_description():

    # ➤ Include another launch file (example: robot_description.launch.py)
    robot_description_pkg = get_package_share_directory("project")
    mobile_robot_launch = os.path.join(
        robot_description_pkg,
        "launch",
        "sim.launch.py"
    )

    include_robot_description = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(mobile_robot_launch)
    )

    # ➤ Controller spawner nodes
    # This spawns joint_state_broadcaster

    return LaunchDescription([
        include_robot_description,
    ])
